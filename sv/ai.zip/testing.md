# Testning och validering - Inera FHIR Implementation Guide Template v2.3.0

## Testning och validering

**Beskriv hur implementatörer kan testa och validera sina implementationer mot denna IG, t.ex. med hjälp av HL7 FHIR Validator och det publicerade IG-paketet (se [Nedladdningar](downloads.md)). Ange eventuell testmiljö eller testdatakälla.**

